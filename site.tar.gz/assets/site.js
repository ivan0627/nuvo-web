(() => {
  "use strict";
  const ENDPOINT = "https://formsubmit.co/ajax/fe480e54b511e119745c398bf106dd94";
  const EMAIL = "ivan.galindo@nuvogroup.co";

  /* mobile CTA bar: after the hero, hidden at the form */
  const bar = document.getElementById("bar");
  const hero = document.querySelector(".hero");
  const formSec = document.querySelector(".cta");
  if (bar && hero && formSec && "IntersectionObserver" in window) {
    let pastHero = false, atForm = false;
    const sync = () => bar.classList.toggle("on", pastHero && !atForm);
    new IntersectionObserver(([e]) => { pastHero = !e.isIntersecting; sync(); }).observe(hero);
    new IntersectionObserver(([e]) => { atForm = e.isIntersecting; sync(); }, { threshold: 0.15 }).observe(formSec);
  }

  const form = document.getElementById("lead");
  if (!form) return;
  const t = form.dataset;
  const send = document.getElementById("send");
  const $ = (id) => document.getElementById(id);
  const fields = {
    nombre: [$("nombre"), $("f-name"), (v) => v.trim().length >= 2],
    oficio: [$("oficio"), $("f-trade"), (v) => v !== ""],
    zona: [$("zona"), $("f-zone"), (v) => v.trim().length >= 2],
    telefono: [$("telefono"), $("f-phone"), (v) => { const n = v.replace(/\D/g, ""); return n.length === 10 || (n.length === 11 && n[0] === "1"); }]
  };
  const check = (k) => {
    const [el, wrap, ok] = fields[k];
    const good = ok(el.value);
    if (good) { wrap.removeAttribute("data-bad"); el.removeAttribute("aria-invalid"); }
    else { wrap.setAttribute("data-bad", ""); el.setAttribute("aria-invalid", "true"); }
    return good;
  };
  Object.keys(fields).forEach((k) => {
    fields[k][0].addEventListener("blur", () => { if (fields[k][0].value) check(k); });
    fields[k][0].addEventListener("input", () => { if (fields[k][1].hasAttribute("data-bad")) check(k); });
  });

  const payload = () => {
    const sel = fields.oficio[0];
    return {
      nombre: fields.nombre[0].value.trim(),
      oficio: sel.options[sel.selectedIndex].text,
      zona: fields.zona[0].value.trim(),
      telefono: fields.telefono[0].value.replace(/\D/g, "").replace(/^1(?=\d{10}$)/, ""),
      idioma: document.documentElement.lang,
      pagina: location.pathname,
      enviado: new Date().toISOString()
    };
  };
  const summary = (p) => `${t.lName}: ${p.nombre}\n${t.lTrade}: ${p.oficio}\n${t.lZone}: ${p.zona}\n${t.lPhone}: ${p.telefono}`;

  const deliver = async (p) => {
    try {
      const r = await fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({ _subject: t.subject + " · " + p.nombre, _template: "table", _captcha: "false", ...p })
      });
      if (!r.ok) return false;
      const j = await r.json().catch(() => ({}));
      return String(j.success) === "true";
    } catch (e) { return false; }
  };

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const bad = Object.keys(fields).filter((k) => !check(k));
    if (bad.length) { fields[bad[0]][0].focus(); return; }
    if ($("hp").value) return;
    const p = payload();
    send.disabled = true;
    send.textContent = t.sending;
    const ok = await deliver(p);
    send.disabled = false;
    send.textContent = t.send;
    if (ok) {
      form.style.display = "none";
      $("fallback").style.display = "none";
      $("done-t").textContent = t.okTitle.replace("{n}", p.nombre.split(" ")[0]);
      $("done").style.display = "block";
      $("done").focus({ preventScroll: true });
      if (window.gtag) window.gtag("event", "generate_lead");
    } else {
      $("fb-mail").href = `mailto:${EMAIL}?subject=${encodeURIComponent(t.subject)}&body=${encodeURIComponent(summary(p))}`;
      const copy = $("fb-copy");
      copy.onclick = async () => {
        try { await navigator.clipboard.writeText(summary(p)); copy.textContent = t.copied; }
        catch (e) { copy.textContent = EMAIL; }
      };
      $("fallback").style.display = "block";
    }
  });
})();
